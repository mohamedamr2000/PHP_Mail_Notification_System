<?php
class DbConnection 
{
  private $connection;
  private static $instance;

  private function __construct()
  {
    $this->database_connect();
  }
  
  public static function getInstance()
  {
    if(self::$instance==null)
    {
      self::$instance=new DbConnection();
    }
    return self::$instance;
  }

  private function database_connect()
  {
    $this->connection = oci_connect('DBName', 'PASS', 'IP');
  }

  public function getConnection()
  {
		return $this->connection;
	}
}
?>