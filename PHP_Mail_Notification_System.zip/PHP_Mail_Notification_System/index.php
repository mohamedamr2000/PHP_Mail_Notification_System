<html>
<head>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
    <link rel ="stylesheet" type="text/css" href="templates/style2.css">
    <link rel="stylesheet" href="templates/bootstrap.css">
</head>
<body>
    <div class="banner-area">
        <div class="content-area">
           <div class="content">
              <h1>Notification System v1.0.0</h1>
              
              <p>By Mohamed Amr</p>
              
              <a href="compose.php" class="btn btn-primary">Proceed</a>
           </div>
        </div>
    </div>
</body>
</html>