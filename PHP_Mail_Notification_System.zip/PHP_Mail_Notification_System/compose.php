<?php
require_once('./controller/compose_cont.php');
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Website Layout | Pylon Notifications</title>
    <link rel="stylesheet" href="templates/style.css">
    <link rel="stylesheet" href="templates/bootstrap.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
   </head>
<body>
<div class="main_box">
<div class="container" style="top: 10px">
        <div class="row">
            <div class="col-lg-10 m-auto">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2>Compose Notification</h2>
                    </div>
                        <div class="card-body">
                        <form method="POST">
                        <table class="table table-bordered" style="border-bottom-style: none; border-right-style: none">
                            <tr style="background-color:#191919; ">
                                <td style="width: 59%; color:white"> <b>Draft</b> </td>
                                <td style="width: 50%; color:white"> <b>Recipenets</b> </td>
                            </tr>

                            <tr>
                              <td style="width: 50%"> <input type="text" name="Subject" placeholder="Subject" class="form-control mb-2"> </td>
                              <td style="width: 50%"> <input type="text" name="Recipenet" placeholder="Recipenet" class="form-control mb-2" required> </td>
                            </tr> 

                            
                            <tr>
                             <td style="width: 50%"> <input type="text" style="height:150px;" name="Body" placeholder="Body" class="form-control mb-2"> </td>
                            </tr>
                            </table> 
                            <div align="left">
                                  <div class="form-check">
                                    <input class="Emailform-check-input" type="checkbox" value="" id="flexCheckDefault">
                                    <label class="form-check-label" for="flexCheckDefault">
                                      Email
                                    </label>
                                  </div>
                                  <div class="form-check">
                                    <input class="Emailform-check-input" type="checkbox" value="" id="flexCheckDefault">
                                    <label class="form-check-label" for="flexCheckDefault">
                                      Push Notification
                                    </label>
                                  </div>
                                  <div class="form-check">
                                    <input class="Emailform-check-input" type="checkbox" value="" id="flexCheckDefault">
                                    <label class="form-check-label" for="flexCheckDefault">
                                      SMS
                                    </label>
                                  </div>
                                </div>     
                        </div>
                    <div class="card-footer">
                    <div align="right">
                            <button class="btn btn-dark" name="btn_send"> Send Notification </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <input type="checkbox" id="check">
    <div class="btn_one">
      <label for="check">
        <i class="fas fa-bars"></i>
      </label>
    </div>
    <div class="sidebar_menu">
      <div class="logo">
        <a href="">Admin Notifications</a>
          </div>
        <div class="btn_two">
          <label for="check">
            <i class="fas fa-times"></i>
          </label>
        </div>
      <div class="menu">
        <ul>
          <li><i class="fas fa-qrcode"></i>
            <a href="compose.php">Compose</a>
          </li>
          <li>
            <i class="fas fa-link"></i>
            <a href="notify_config.php">Configuration</a>
          </li>
          <li>
            <i class="fas fa-question-circle"></i>
            <a href="#">Help</a>
          </li>
        </ul>
      </div>
    </div>
  </div>
  </body>
</html>
