<?php
require_once('./controller/notify_config_cont.php');
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Website Layout | Pylon Notifications</title>
    <link rel="stylesheet" href="templates/style.css">
    <link rel="stylesheet" href="templates/bootstrap.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
   </head>
<body>
<div class="main_box">
<div class="container" style="top: 10px">
        <div class="row">
            <div class="col-lg-10 m-auto">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2>Server Settings</h2>
                    </div>
                        <div class="card-body">
                        <button style="margin-bottom: 16px"  class="btn btn-danger" name="btn_publish"> Vodafone </button>
                        <button style="margin-bottom: 16px"  class="btn btn-warning" name="btn_publish"> Orange </button>
                        <button style="margin-bottom: 16px"  class="btn btn-success" name="btn_publish"> Etisalat </button>
                        <button style="margin-bottom: 16px"  class="btn btn-info" name="btn_publish"> WE </button>
                        <form method="POST">
                        <table class="table table-bordered" style="border-bottom-style: none; border-right-style: none">
                            <tr style="background-color:#191919">
                                <td style="width: 50%; color:white"> <b>SMS</b> </td>
                                <td style="width: 50%; color:white"> <b>Email</b> </td>
                            </tr>

                            <tr>
                              <td style="width: 50%"> <input type="text" name="URL" placeholder="URL" class="form-control mb-2"> </td>
                              <td style="width: 50%"> <input type="text" name="Host" placeholder="Host" class="form-control mb-2" required> </td>
                            </tr> 

                            
                            <tr>
                             <td style="width: 50%"> <input type="text" name="Account ID" placeholder="Account ID" class="form-control mb-2"> </td>
                              <td style="width: 50%"> <input type="text" name="Port" placeholder="Port" class="form-control mb-2" required> </td>
                            </tr>

                            
                            <tr>
                              <td style="width: 50%"> <input type="text" name="Password" placeholder="Password" class="form-control mb-2"> </td>
                              <td style="width: 50%"> <input type="text" name="User" placeholder="User" class="form-control mb-2" required> </td>
                            </tr>

                            
                            <tr>
                              <td style="width: 50%"> <input type="text" name="MSISDN" placeholder="MSISDN" class="form-control mb-2"> </td>
                              <td style="width: 50%"> <input type="text" name="Mail_Password" placeholder="Mail Password" class="form-control mb-2" required> </td>
                            </tr>

                            
                            <tr>
                              <td style="width: 50%"> <input type="text" name="Sender Name" placeholder="Sender Name" class="form-control mb-2"> </td>
                            </tr>

                            </table>      
                        </div>
                    <div class="card-footer">
                    <div align="right">
                            <button class="btn btn-dark" name="btn_save"> Save </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <input type="checkbox" id="check">
    <div class="btn_one">
      <label for="check">
        <i class="fas fa-bars"></i>
      </label>
    </div>
    <div class="sidebar_menu">
      <div class="logo">
        <a href="">Admin Notifications</a>
          </div>
        <div class="btn_two">
          <label for="check">
            <i class="fas fa-times"></i>
          </label>
        </div>
      <div class="menu">
        <ul>
          <li><i class="fas fa-qrcode"></i>
            <a href="compose.php">Compose</a>
          </li>
          <li>
            <i class="fas fa-link"></i>
            <a href="notify_config.php">Configuration</a>
          </li>
          <li>
            <i class="fas fa-question-circle"></i>
            <a href="#">Help</a>
          </li>
        </ul>
      </div>
    </div>
  </div>
  </body>
</html>
